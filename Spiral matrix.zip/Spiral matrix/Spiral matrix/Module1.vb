﻿Module Module1
    Dim n, m As Single

    Sub Main()
        Dim a() As String = Console.ReadLine().Split
        n = CInt(a(0))
        m = CInt(a(1))
        Dim round(n, n) As Single
        Dim chack(n + 2, n + 2) As Single

        For i = 1 To n
            For j = 1 To n
                round(i, j) = j
            Next
        Next


    End Sub
End Module
